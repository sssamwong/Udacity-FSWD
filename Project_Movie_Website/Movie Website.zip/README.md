#Movie Website

This is a simple website showing movies I enjoy watching.


**Installation**

Code was written in python 2 which could be download from the below:

https://www.python.org/downloads/


**Usage**

Before you run the code in either IDLE or sublime, you should unzip the files^ and ensure they stored in the same directory.

	i.		open IDLE/Sublime
	ii.		run entertainment_center.py
	iii. 	a HTML website should pop up or you could use the generated html file

**Contribution**
Any further good improvement please send an email to siuswong6@gmail.com

**Issue**
Should be free of issues but do send an email to siuswong6@gmail.com if any

**License**
Too simple for any license

